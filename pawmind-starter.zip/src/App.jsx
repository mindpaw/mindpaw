import { useState } from "react";
import { signInWithGoogle } from "./auth";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const moodData = [
  { day: "Mon", mood: 80 },
  { day: "Tue", mood: 60 },
  { day: "Wed", mood: 70 },
  { day: "Thu", mood: 90 },
  { day: "Fri", mood: 65 },
];

function App() {
  const [user, setUser] = useState(null);

  const handleGoogleLogin = async () => {
    const loggedInUser = await signInWithGoogle();
    setUser(loggedInUser);
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">PawMind App</h1>
      {!user ? (
        <button onClick={handleGoogleLogin} className="bg-blue-500 text-white px-4 py-2 rounded">
          Sign in with Google
        </button>
      ) : (
        <div>
          <p>Welcome, {user.displayName}</p>
          <h2 className="text-xl mt-6 mb-2">Mood Chart</h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={moodData}>
              <XAxis dataKey="day" />
              <YAxis domain={[0, 100]} hide />
              <Tooltip />
              <Line type="monotone" dataKey="mood" stroke="#3b82f6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

export default App;
